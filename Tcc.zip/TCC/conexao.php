<?php

$mysqli = new mysqli("localhost:3307","root","","Teste_personalidade");
if (mysqli_connect_error()){
    echo ("Erro de conexao:".mysql.conect_error());
    exit();
    
}
?>

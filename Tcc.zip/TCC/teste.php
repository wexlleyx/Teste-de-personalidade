
<html>
    <head>
        <meta charset="UTF-8">
        <title>Identifier</title>
        <link rel="stylesheet" href="css/bootstrap.min.css">
            <style>
            body{
                font-size:  20;
               
        background-image: url("background2.jpg");
    }
               
 
            #corpo{
                border: 12px #146c43 ridge ;
                margin-top: 20px;
            }
            
        </style>
    </head>
    <body>
    
        <nav class="nav navbar-dark bg-dark">
  <a class="nav-link active" aria-current="page" href="index.php">Página principal</a>
</nav>
        <div id="corpo" class="container">
        <form action="resultado.php" method="POST" align='center'>
            <h1 align='center'> Cadastro concluído!</h1>
            <h2 align="center" style="color: red"> Atenção! </h2>
                <h4 align="center"> Responda sinceramente, não do jeito que você acha que deveria ser, mas do jeito que você é. </h4>
                <br>
        
                Você costuma iniciar as conversas e frequentemente conversa com estranhos na rua. <Select name="q1" id="q1" style="">
                <option value=""></option>
                <option value="a1">Tudo a ver comigo</option>
                <option value="b1">Tem a ver comigo</option>
                <option value="c1">Pouco a ver comigo</option>
                <option value="d1">Nada a ver comigo</option>
                </select>
                
                
                
                                    
                
                <br> <br>
                
                Você fica frequentemente tão absorto em seus pensamentos que ignora ou esquece do seu entorno. <Select name="q2" id="q2">
                <option value=""></option>
                <option value="a2">Tudo a ver comigo</option>
                <option value="b2">Tem a ver comigo</option>
                <option value="c2">Pouco a ver comigo</option>
                <option value="d2">Nada a ver comigo</option>
                </select>
                
                <br> <br>
                
                Você permanece relaxado e concentrado mesmo sob pressão. <Select name="q3" id="q3">
                <option value=""></option>
                <option value="a3">Tudo a ver comigo</option>
                <option value="b3">Tem a ver comigo</option>
                <option value="c3">Pouco a ver comigo</option>
                <option value="d3">Nada a ver comigo</option>
                </select>
                
                <br> <br>
                
                Você tenta responder aos seus e-mails o mais rapidamente possível e não suporta uma caixa de entrada bagunçada. <Select name="q4" id="q4">
                <option value=""></option>
                <option value="a4">Tudo a ver comigo</option>
                <option value="b4">Tem a ver comigo</option>
                <option value="c4">Pouco a ver comigo</option>
                <option value="d4">Nada a ver comigo</option>
                </select>
                
                <br> <br>
                
                Você acha difícil se apresentar para outras pessoas. <Select name="q5" id="q5">
                <option value=""></option>
                <option value="a5">Tudo a ver comigo</option>
                <option value="b5">Tem a ver comigo</option>
                <option value="c5">Pouco a ver comigo</option>
                <option value="d5">Nada a ver comigo</option>
                </select>
                
                <br> <br>
                
                Você se considera mais prático do que criativo. <Select name="q6" id="q6">
                <option value=""></option>
                <option value="a6">Tudo a ver comigo</option>
                <option value="b6">Tem a ver comigo</option>
                <option value="c6">Pouco a ver comigo</option>
                <option value="d6">Nada a ver comigo</option>
                </select>
                
                <br> <br>
                
                Frequentemente, é difícil para você se relacionar com os sentimentos das outras pessoas. <Select name="q7" id="q7">
                <option value=""></option>
                <option value="a7">Tudo a ver comigo</option>
                <option value="b7">Tem a ver comigo</option>
                <option value="c7">Pouco a ver comigo</option>
                <option value="d7">Nada a ver comigo</option>
                </select>
                
                <br> <br>
                
                Ser organizado é mais importante para você do que ser adaptável. <Select name="q8" id="q8">
                <option value=""></option>
                <option value="a8">Tudo a ver comigo</option>
                <option value="b8">Tem a ver comigo</option>
                <option value="c8">Pouco a ver comigo</option>
                <option value="d8">Nada a ver comigo</option>
                </select>
                
                <br> <br>
                
                Você gosta de ser o centro das atenções. <Select name="q9" id="q9">
                <option value=""></option>
                <option value="a9">Tudo a ver comigo</option>
                <option value="b9">Tem a ver comigo</option>
                <option value="c9">Pouco a ver comigo</option>
                <option value="d9">Nada a ver comigo</option>
                </select>
                
                <br> <br>
                
                Você raramente se deixa levar por fantasias e ideias. <Select name="q10" id="q10">
                <option value=""></option>
                <option value="a10">Tudo a ver comigo</option>
                <option value="b10">Tem a ver comigo</option>
                <option value="c10">Pouco a ver comigo</option>
                <option value="d10">Nada a ver comigo</option>
                </select>
                
                <br> <br>
                
                Pra você, em uma discussão a verdade deve ser mais importante que a sensibilidade das pessoas. <Select name="q11" id="q11">
                <option value=""></option>
                <option value="a11">Tudo a ver comigo</option>
                <option value="b11">Tem a ver comigo</option>
                <option value="c11">Pouco a ver comigo</option>
                <option value="d11">Nada a ver comigo</option>
                </select>
                
                <br> <br>

                Seus ambientes doméstico e de trabalho são muito organizados, metodicamente. <Select name="q12" id="q12">
                <option value=""></option>
                <option value="a12">Tudo a ver comigo</option>
                <option value="b12">Tem a ver comigo</option>
                <option value="c12">Pouco a ver comigo</option>
                <option value="d12">Nada a ver comigo</option>
                </select>
                
                <br> <br>
                
                Um livro ou um vídeo game interessante é frequentemente melhor que um evento social. <Select name="q13" id="q13">
                <option value=""></option>
                <option value="a13">Tudo a ver comigo</option>
                <option value="b13">Tem a ver comigo</option>
                <option value="c13">Pouco a ver comigo</option>
                <option value="d13">Nada a ver comigo</option>
                </select>
                
                <br> <br>
                
                Você se vê frequentemente perdido em seus pensamentos quando está em contato com a natureza. <Select name="q14" id="q14">
                <option value=""></option>
                <option value="a14">Tudo a ver comigo</option>
                <option value="b14">Tem a ver comigo</option>
                <option value="c14">Pouco a ver comigo</option>
                <option value="d14">Nada a ver comigo</option>
                </select>
                
                <br><br>
                
                Como pai/mãe, preferiria de ver seu/sua filho(a) crescer bondoso(a) do que inteligente. <Select name="q15" id="q15">
                <option value=""></option>
                <option value="a15">Tudo a ver comigo</option>
                <option value="b15">Tem a ver comigo</option>
                <option value="c15">Pouco a ver comigo</option>
                <option value="d15">Nada a ver comigo</option>
                </select>
                
                <br><br>
                
                Não leva muito tempo para você começar a se envolver em atividades sociais em seu novo local de trabalho. <Select name="q16" id="q16">
                <option value=""></option>
                <option value="a16">Tudo a ver comigo</option>
                <option value="b16">Tem a ver comigo</option>
                <option value="c16">Pouco a ver comigo</option>
                <option value="d16">Nada a ver comigo</option>
                </select>
                
                <br><br>
                
                Você é mais um improvisador nato do que um planejador cuidadoso.<Select name="q17" id="q17">
                <option value=""></option>
                <option value="a17">Tudo a ver comigo</option>
                <option value="b17">Tem a ver comigo</option>
                <option value="c17">Pouco a ver comigo</option>
                <option value="d17">Nada a ver comigo</option>
                </select>
                
                <br><br>
                
                Suas emoções o controlam mais do que você as controla.<Select name="q18" id="q18">
                <option value=""></option>
                <option value="a18">Tudo a ver comigo</option>
                <option value="b18">Tem a ver comigo</option>
                <option value="c18">Pouco a ver comigo</option>
                <option value="d18">Nada a ver comigo</option>
                </select>
                
                <br><br>
                
                Você frequentemente despende tempo explorando ideias irrealistas e impraticáveis, ainda que intrigantes.<Select name="q19" id="q19">
                <option value=""></option>
                <option value="a19">Tudo a ver comigo</option>
                <option value="b19">Tem a ver comigo</option>
                <option value="c19">Pouco a ver comigo</option>
                <option value="d19">Nada a ver comigo</option>
                </select>
                
                <br><br>
                
                
                Você prefere improvisar do que despender tempo para criar um plano detalhado.<Select name="q20" id="q20">
                <option value=""></option>
                <option value="a20">Tudo a ver comigo</option>
                <option value="b20">Tem a ver comigo</option>
                <option value="c20">Pouco a ver comigo</option>
                <option value="d20">Nada a ver comigo</option>
                </select>
                
                <br><br>
                
                
                
                Se você tivesse uma empresa, acharia muito difícil demitir funcionários leais mas com baixo desempenho.<Select name="q21" id="q21">
                <option value=""></option>
                <option value="a21">Tudo a ver comigo</option>
                <option value="b21">Tem a ver comigo</option>
                <option value="c21">Pouco a ver comigo</option>
                <option value="d21">Nada a ver comigo</option>
                </select>
                
                <br><br>
                
                
                Você frequentemente contempla as razões da existência humana.<Select name="q22" id="q22">
                <option value=""></option>
                <option value="a22">Tudo a ver comigo</option>
                <option value="b22">Tem a ver comigo</option>
                <option value="c22">Pouco a ver comigo</option>
                <option value="d22">Nada a ver comigo</option>
                </select>
                
                <br><br>
                
                
                A lógica é geralmente mais importante que o coração na hora de se tomar decisões importantes.<Select name="q23" id="q23">
                <option value=""></option>
                <option value="a23">Tudo a ver comigo</option>
                <option value="b23">Tem a ver comigo</option>
                <option value="c23">Pouco a ver comigo</option>
                <option value="d23">Nada a ver comigo</option>
                </select>
                
                <br><br>
                
                
                Você geralmente acha difícil relaxar ao se dirigir para muitas pessoas.<Select name="q24" id="q24">
                <option value=""></option>
                <option value="a24">Tudo a ver comigo</option>
                <option value="b24">Tem a ver comigo</option>
                <option value="c24">Pouco a ver comigo</option>
                <option value="d24">Nada a ver comigo</option>
                </select>
                
                <br><br>
                
                
                Você acredita que é mais recompensador ser querido pelos outros do que poderoso. <Select name="q25" id="q25">
                <option value=""></option>
                <option value="a25">Tudo a ver comigo</option>
                <option value="b25">Tem a ver comigo</option>
                <option value="c25">Pouco a ver comigo</option>
                <option value="d25">Nada a ver comigo</option>
                </select>
                
                <br><br>
                
                
                Você sempre foi interessado em coisas não convencionais e ambíguas, por ex., em livros, arte, músicas ou filmes. <Select name="q26" id="q26">
                <option value=""></option>
                <option value="a26">Tudo a ver comigo</option>
                <option value="b26">Tem a ver comigo</option>
                <option value="c26">Pouco a ver comigo</option>
                <option value="d26">Nada a ver comigo</option>
                </select>
                
                <br><br>
                
        
                <input type="submit" value="Finalizar teste" style="color: blue" > 
                <input type="reset" value="Cancelar" style="color: red">
        </form>
       </div>
       
        <?php
        
       
        ?>
    </body>
</html>


